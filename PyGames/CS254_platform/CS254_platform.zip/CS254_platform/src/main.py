import pygame, sys, os
from pygame.locals import *
from Player import Player
from Background import Background
from Platform import Platform
from CONST import *


def main():
    
    pygame.init()
    clock = pygame.time.Clock()

    player = Player()
    bg = Background()
    
    PLAYERS.add( player )
    PLATFORMS.add( Platform((200, 250), "platform1") )
    PLATFORMS.add( Platform((600, 275), "platform1") )
      
    while True:
        clock.tick(120)
        for event in pygame.event.get():
            if event.type == QUIT or (event.type == KEYDOWN and event.key == K_q):
                pygame.quit()
                sys.exit()      
              
        bg.update()
        PLATFORMS.update(bg.x, 0)
        PLAYERS.update()
        
        PLAYERS.draw(screen)
        PLATFORMS.draw(screen)
        
        
        pygame.display.flip()
        
    

  
if __name__ == '__main__':
    main()
