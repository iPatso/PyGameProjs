from CONST import *

class Platform(pygame.sprite.Sprite):
    def __init__(self, pos, name):
        
        pygame.sprite.Sprite.__init__(self)
        
        self.image = pygame.image.load(os.path.join("data", name+".png")).convert_alpha()
        self.rect = self.image.get_rect()
        self.init_pos = pos
        self.rect.center = pos
        
    def update(self, bg_x, bg_y):
        
        self.rect.center = (bg_x + self.init_pos[0], bg_y + self.init_pos[1])